﻿namespace Bai3
{
    partial class Ước_số
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnExit = new Button();
            btnCountUocChan = new Button();
            btnCountUocNgto = new Button();
            btnSumUoc = new Button();
            groupBox2 = new GroupBox();
            listBox1 = new ListBox();
            groupBox1 = new GroupBox();
            CbSo = new ComboBox();
            btnUpdate = new Button();
            txtInput = new TextBox();
            groupBox2.SuspendLayout();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // btnExit
            // 
            btnExit.BackColor = SystemColors.ButtonShadow;
            btnExit.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnExit.Location = new Point(181, 287);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(99, 51);
            btnExit.TabIndex = 7;
            btnExit.Text = "Thoát";
            btnExit.UseVisualStyleBackColor = false;
            // 
            // btnCountUocChan
            // 
            btnCountUocChan.BackColor = SystemColors.ButtonShadow;
            btnCountUocChan.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCountUocChan.Location = new Point(434, 250);
            btnCountUocChan.Name = "btnCountUocChan";
            btnCountUocChan.Size = new Size(239, 41);
            btnCountUocChan.TabIndex = 11;
            btnCountUocChan.Text = "Số lượng các ước số chẵn";
            btnCountUocChan.UseVisualStyleBackColor = false;
            btnCountUocChan.Click += btnCountUocChan_Click;
            // 
            // btnCountUocNgto
            // 
            btnCountUocNgto.BackColor = SystemColors.ButtonShadow;
            btnCountUocNgto.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnCountUocNgto.Location = new Point(434, 297);
            btnCountUocNgto.Name = "btnCountUocNgto";
            btnCountUocNgto.Size = new Size(239, 41);
            btnCountUocNgto.TabIndex = 10;
            btnCountUocNgto.Text = "Số lượng các ước số nguyên tố";
            btnCountUocNgto.UseVisualStyleBackColor = false;
            btnCountUocNgto.Click += btnCountUocNgto_Click;
            // 
            // btnSumUoc
            // 
            btnSumUoc.BackColor = SystemColors.ButtonShadow;
            btnSumUoc.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnSumUoc.Location = new Point(434, 203);
            btnSumUoc.Name = "btnSumUoc";
            btnSumUoc.Size = new Size(239, 41);
            btnSumUoc.TabIndex = 8;
            btnSumUoc.Text = "Tổng các ước số";
            btnSumUoc.UseVisualStyleBackColor = false;
            btnSumUoc.Click += btnSumUoc_Click;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(listBox1);
            groupBox2.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox2.Location = new Point(434, 32);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(239, 135);
            groupBox2.TabIndex = 9;
            groupBox2.TabStop = false;
            groupBox2.Text = "Danh sách các ước số";
            // 
            // listBox1
            // 
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 22;
            listBox1.Location = new Point(19, 36);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(168, 70);
            listBox1.TabIndex = 0;
            listBox1.SelectedIndexChanged += listBox1_SelectedIndexChanged;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(CbSo);
            groupBox1.Controls.Add(btnUpdate);
            groupBox1.Controls.Add(txtInput);
            groupBox1.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(41, 32);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(239, 135);
            groupBox1.TabIndex = 6;
            groupBox1.TabStop = false;
            groupBox1.Text = "Nhập số";
            // 
            // CbSo
            // 
            CbSo.FormattingEnabled = true;
            CbSo.Location = new Point(25, 98);
            CbSo.Name = "CbSo";
            CbSo.Size = new Size(172, 30);
            CbSo.TabIndex = 2;
            CbSo.SelectedIndexChanged += CbSo_SelectedIndexChanged;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = SystemColors.ButtonShadow;
            btnUpdate.Location = new Point(134, 30);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(99, 51);
            btnUpdate.TabIndex = 1;
            btnUpdate.Text = "Cập nhật";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += BtnCapNhat_Click;
            // 
            // txtInput
            // 
            txtInput.Location = new Point(9, 41);
            txtInput.Name = "txtInput";
            txtInput.Size = new Size(97, 30);
            txtInput.TabIndex = 0;
           
            // 
            // Ước_số
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnExit);
            Controls.Add(btnCountUocChan);
            Controls.Add(btnCountUocNgto);
            Controls.Add(btnSumUoc);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "Ước_số";
            Text = "Ước_số";
            groupBox2.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Button btnExit;
        private Button btnCountUocChan;
        private Button btnCountUocNgto;
        private Button btnSumUoc;
        private GroupBox groupBox2;
        private ListBox listBox1;
        private GroupBox groupBox1;
        private ComboBox CbSo;
        private Button btnUpdate;
        private TextBox txtInput;
    }
}