﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Bai3
{
    public partial class Ước_số : Form
    {
        public Ước_số()
        {
            InitializeComponent();
        }

        private void TxtNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {
                BtnCapNhat_Click(sender, e);
                e.Handled = true;
            }
        }

        private void BtnCapNhat_Click(object sender, EventArgs e)
        {
            string input = txtInput.Text.Trim();

            // Kiểm tra nhập có phải số nguyên dương
            if (!int.TryParse(input, out int num) || num <= 0)
            {
                MessageBox.Show("Vui lòng nhập một số nguyên dương hợp lệ.", "Lỗi nhập liệu",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtInput.SelectAll();
                txtInput.Focus();
                return;
            }

            // Thêm số vào ComboBox nếu chưa có
            if (!CbSo.Items.Contains(num))
                CbSo.Items.Add(num);

            CbSo.SelectedItem = num;
            listBox1.Items.Clear();  // Xóa các ước số cũ trước khi thêm mới
            int[] divisors = GetDivisors(num);  // Lấy các ước số của số đã nhập
            foreach (var divisor in divisors)
            {
                listBox1.Items.Add(divisor);  // Thêm mỗi ước số vào ListBox
            }
            // Xóa TextBox và đặt con trỏ lại
            txtInput.Clear();
            txtInput.Focus();
            txtInput.SelectAll();
        }


        private int[] GetDivisors(int number)
        {
            // Tính số lượng ước số của number
            int count = 0;
            for (int i = 1; i <= number; i++)
            {
                if (number % i == 0)
                {
                    count++;
                }
            }

            // Tạo mảng để chứa các ước số
            int[] divisors = new int[count];
            int index = 0;

            // Lưu các ước số vào mảng
            for (int i = 1; i <= number; i++)
            {
                if (number % i == 0)
                {
                    divisors[index] = i;
                    index++;
                }
            }

            return divisors;
        }
        private void CbSo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (CbSo.SelectedItem != null)
            {
                MessageBox.Show($"Selected number: {CbSo.SelectedItem}");
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                int selectedDivisor = (int)listBox1.SelectedItem;  // Lấy ước số đã chọn từ listBox1

                // Tính tất cả các ước số của số đã chọn
                int[] divisors = GetDivisors(selectedDivisor);

                // Hiển thị tất cả các ước số trong MessageBox
                string divisorsString = string.Join(", ", divisors);
                MessageBox.Show($"All divisors of {selectedDivisor}: {divisorsString}");
            }
        }

        private void btnSumUoc_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtInput.Text, out int number))
            {
                int sum = 0;
                for (int i = 1; i <= number; i++)
                {
                    if (number % i == 0)
                    {
                        sum += i;
                    }
                }
                MessageBox.Show($"Sum of divisors: {sum}");
            }
            else
            {
                MessageBox.Show("Please enter a valid number.");
            }
        }

        private void btnCountUocChan_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtInput.Text, out int number))
            {
                int count = 0;
                for (int i = 1; i <= number; i++)
                {
                    if (number % i == 0 && i % 2 == 0)
                    {
                        count++;
                    }
                }
                MessageBox.Show($"Number of even divisors: {count}");
            }
            else
            {
                MessageBox.Show("Please enter a valid number.");
            }
        }

        private void btnCountUocNgto_Click(object sender, EventArgs e)
        {
            if (int.TryParse(txtInput.Text, out int number))
            {
                int count = 0;
                for (int i = 1; i <= number; i++)
                {
                    if (number % i == 0 && IsPrime(i))
                    {
                        count++;
                    }
                }
                MessageBox.Show($"Number of prime divisors: {count}");
            }
            else
            {
                MessageBox.Show("Please enter a valid number.");
            }
        }
        private bool IsPrime(int number)
        {
            if (number < 2) return false;
            for (int i = 2; i <= Math.Sqrt(number); i++)
            {
                if (number % i == 0) return false;
            }
            return true;
        }
    }
}