﻿namespace Bai1
{
    partial class Form_Đăng_nhập
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            name = new Label();
            txtUser = new TextBox();
            label1 = new Label();
            txtPass = new TextBox();
            chkNho = new CheckBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            SuspendLayout();
            // 
            // name
            // 
            name.AutoSize = true;
            name.Font = new Font("Times New Roman", 13.2000008F, FontStyle.Regular, GraphicsUnit.Point, 0);
            name.Location = new Point(19, 44);
            name.Name = "name";
            name.Size = new Size(151, 26);
            name.TabIndex = 0;
            name.Text = "Tên đăng nhập";
            // 
            // txtUser
            // 
            txtUser.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtUser.Location = new Point(176, 43);
            txtUser.Name = "txtUser";
            txtUser.Size = new Size(426, 30);
            txtUser.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 13.2000008F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(19, 160);
            label1.Name = "label1";
            label1.Size = new Size(99, 26);
            label1.TabIndex = 2;
            label1.Text = "Mật khẩu";
            // 
            // txtPass
            // 
            txtPass.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtPass.Location = new Point(176, 160);
            txtPass.Name = "txtPass";
            txtPass.Size = new Size(426, 30);
            txtPass.TabIndex = 3;
            // 
            // chkNho
            // 
            chkNho.AutoSize = true;
            chkNho.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            chkNho.Location = new Point(94, 239);
            chkNho.Name = "chkNho";
            chkNho.Size = new Size(95, 26);
            chkNho.TabIndex = 4;
            chkNho.Text = "Ghi nhớ";
            chkNho.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ButtonShadow;
            button1.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.Location = new Point(46, 321);
            button1.Name = "button1";
            button1.Size = new Size(143, 46);
            button1.TabIndex = 5;
            button1.Text = "Đăng nhập";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ButtonShadow;
            button2.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button2.Location = new Point(322, 321);
            button2.Name = "button2";
            button2.Size = new Size(143, 46);
            button2.TabIndex = 6;
            button2.Text = "Xóa";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.ButtonShadow;
            button3.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button3.Location = new Point(591, 321);
            button3.Name = "button3";
            button3.Size = new Size(143, 46);
            button3.TabIndex = 7;
            button3.Text = "Dừng";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // Form_Đăng_nhập
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(chkNho);
            Controls.Add(txtPass);
            Controls.Add(label1);
            Controls.Add(txtUser);
            Controls.Add(name);
            Name = "Form_Đăng_nhập";
            Text = "Form_Đăng_nhập";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label name;
        private TextBox txtUser;
        private Label label1;
        private TextBox txtPass;
        private CheckBox chkNho;
        private Button button1;
        private Button button2;
        private Button button3;
    }
}