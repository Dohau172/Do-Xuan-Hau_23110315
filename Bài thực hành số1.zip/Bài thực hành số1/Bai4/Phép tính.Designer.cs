﻿namespace Bai4
{
    partial class Phép_tính
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            number1 = new TextBox();
            number2 = new TextBox();
            groupBox1 = new GroupBox();
            radChia = new RadioButton();
            radNhan = new RadioButton();
            radTru = new RadioButton();
            radCong = new RadioButton();
            label3 = new Label();
            btnKQ = new Button();
            txtKQ = new TextBox();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(53, 57);
            label1.Name = "label1";
            label1.Size = new Size(46, 22);
            label1.TabIndex = 0;
            label1.Text = "Số 1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.Location = new Point(53, 122);
            label2.Name = "label2";
            label2.Size = new Size(46, 22);
            label2.TabIndex = 1;
            label2.Text = "Số 2";
            // 
            // number1
            // 
            number1.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            number1.Location = new Point(150, 54);
            number1.Name = "number1";
            number1.Size = new Size(393, 30);
            number1.TabIndex = 2;
            // 
            // number2
            // 
            number2.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            number2.Location = new Point(150, 119);
            number2.Name = "number2";
            number2.Size = new Size(393, 30);
            number2.TabIndex = 3;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(radChia);
            groupBox1.Controls.Add(radNhan);
            groupBox1.Controls.Add(radTru);
            groupBox1.Controls.Add(radCong);
            groupBox1.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(55, 196);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(485, 135);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "Phép tính";
            // 
            // radChia
            // 
            radChia.AutoSize = true;
            radChia.Location = new Point(398, 49);
            radChia.Name = "radChia";
            radChia.Size = new Size(68, 26);
            radChia.TabIndex = 3;
            radChia.TabStop = true;
            radChia.Text = "Chia";
            radChia.UseVisualStyleBackColor = true;
            this.radChia.CheckedChanged += new System.EventHandler(this.radChia_CheckedChanged);
            // 
            // radNhan
            // 
            radNhan.AutoSize = true;
            radNhan.Location = new Point(283, 49);
            radNhan.Name = "radNhan";
            radNhan.Size = new Size(72, 26);
            radNhan.TabIndex = 2;
            radNhan.TabStop = true;
            radNhan.Text = "Nhân";
            radNhan.UseVisualStyleBackColor = true;
            radNhan.CheckedChanged += radNhan_CheckedChanged;
            // 
            // radTru
            // 
            radTru.AutoSize = true;
            radTru.Location = new Point(145, 49);
            radTru.Name = "radTru";
            radTru.Size = new Size(60, 26);
            radTru.TabIndex = 1;
            radTru.TabStop = true;
            radTru.Text = "Trừ";
            radTru.UseVisualStyleBackColor = true;
            radTru.CheckedChanged += radTru_CheckedChanged;
            // 
            // radCong
            // 
            radCong.AutoSize = true;
            radCong.Location = new Point(16, 49);
            radCong.Name = "radCong";
            radCong.Size = new Size(72, 26);
            radCong.TabIndex = 0;
            radCong.TabStop = true;
            radCong.Text = "Cộng";
            radCong.UseVisualStyleBackColor = true;
            radCong.CheckedChanged += radCong_CheckedChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(83, 362);
            label3.Name = "label3";
            label3.Size = new Size(0, 22);
            label3.TabIndex = 5;
            // 
            // btnKQ
            // 
            btnKQ.BackColor = SystemColors.ButtonShadow;
            btnKQ.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnKQ.Location = new Point(33, 362);
            btnKQ.Name = "btnKQ";
            btnKQ.Size = new Size(150, 50);
            btnKQ.TabIndex = 6;
            btnKQ.Text = "Kết quả";
            btnKQ.UseVisualStyleBackColor = false;
            // 
            // txtKQ
            // 
            txtKQ.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtKQ.Location = new Point(200, 373);
            txtKQ.Name = "txtKQ";
            txtKQ.Size = new Size(321, 30);
            txtKQ.TabIndex = 7;
            // 
            // Phép_tính
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(txtKQ);
            Controls.Add(btnKQ);
            Controls.Add(label3);
            Controls.Add(groupBox1);
            Controls.Add(number2);
            Controls.Add(number1);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Phép_tính";
            Text = "Phép_tính";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private TextBox number1;
        private TextBox number2;
        private GroupBox groupBox1;
        private RadioButton radChia;
        private RadioButton radNhan;
        private RadioButton radTru;
        private RadioButton radCong;
        private Label label3;
        private Button btnKQ;
        private TextBox txtKQ;
    }
}