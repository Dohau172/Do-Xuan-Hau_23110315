﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bai4
{
    public partial class Phép_tính : Form
    {
        public Phép_tính()
        {
            InitializeComponent();
        }

        private void radCong_CheckedChanged(object sender, EventArgs e)
        {
            //Phep cong
            int a = int.Parse(number1.Text);
            int b = int.Parse(number2.Text);
            int kq = a + b;
            txtKQ.Text = kq.ToString();

        }

        private void radTru_CheckedChanged(object sender, EventArgs e)
        {
            //Phep tru
            int a = int.Parse(number1.Text);
            int b = int.Parse(number2.Text);
            int kq = a - b;
            txtKQ.Text = kq.ToString();
        }

        private void radNhan_CheckedChanged(object sender, EventArgs e)
        {
            int a = int.Parse(number1.Text);
            int b = int.Parse(number2.Text);
            int kq = a * b;
            txtKQ.Text = kq.ToString();
        }
        private void radChia_CheckedChanged(object sender, EventArgs e)
        {
            // Only execute if the RadioButton is checked
            if (radChia.Checked)
            {
                try
                {
                    // Validate input for number1 and number2
                    if (string.IsNullOrWhiteSpace(number1.Text) || string.IsNullOrWhiteSpace(number2.Text))
                    {
                        MessageBox.Show("Vui lòng nhập cả hai số.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        txtKQ.Text = "";
                        return;
                    }

                    // Parse input to integers
                    if (!int.TryParse(number1.Text, out int a) || !int.TryParse(number2.Text, out int b))
                    {
                        MessageBox.Show("Vui lòng nhập số nguyên hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtKQ.Text = "";
                        return;
                    }

                    // Check for division by zero
                    if (b == 0)
                    {
                        MessageBox.Show("Không thể chia cho 0.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtKQ.Text = "";
                        return;
                    }

                    // Perform division and display result
                    float kq = (float)a / b; // Explicit cast to float for division
                    txtKQ.Text = kq.ToString("F2"); // Format to 2 decimal places for readability
                }
                catch (Exception ex)
                {
                    // Catch any unexpected errors
                    MessageBox.Show($"Đã xảy ra lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    txtKQ.Text = "";
                }
            }
        }

    }
}
