﻿namespace Bai2
{
    partial class Đổi_kiểu_chữ
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtHoTen = new TextBox();
            groupBox1 = new GroupBox();
            rad2 = new RadioButton();
            rad1 = new RadioButton();
            btnXoa = new Button();
            btnKQ = new Button();
            txtKQ = new TextBox();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 12F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 0);
            label1.Location = new Point(38, 31);
            label1.Name = "label1";
            label1.Size = new Size(142, 23);
            label1.TabIndex = 0;
            label1.Text = "Nhập họ và tên:";
            // 
            // txtHoTen
            // 
            txtHoTen.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtHoTen.Location = new Point(212, 31);
            txtHoTen.Name = "txtHoTen";
            txtHoTen.Size = new Size(427, 30);
            txtHoTen.TabIndex = 1;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rad2);
            groupBox1.Controls.Add(rad1);
            groupBox1.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(46, 104);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(477, 124);
            groupBox1.TabIndex = 2;
            groupBox1.TabStop = false;
            groupBox1.Text = "Đổi kiểu chữ";
            // 
            // rad2
            // 
            rad2.AutoSize = true;
            rad2.Location = new Point(23, 77);
            rad2.Name = "rad2";
            rad2.Size = new Size(121, 26);
            rad2.TabIndex = 1;
            rad2.TabStop = true;
            rad2.Text = "CHỮ HOA";
            rad2.UseVisualStyleBackColor = true;
            // 
            // rad1
            // 
            rad1.AutoSize = true;
            rad1.Location = new Point(23, 30);
            rad1.Name = "rad1";
            rad1.Size = new Size(119, 26);
            rad1.TabIndex = 0;
            rad1.TabStop = true;
            rad1.Text = "chữ thường";
            rad1.UseVisualStyleBackColor = true;
            // 
            // btnXoa
            // 
            btnXoa.BackColor = SystemColors.ButtonShadow;
            btnXoa.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnXoa.Location = new Point(542, 121);
            btnXoa.Name = "btnXoa";
            btnXoa.Size = new Size(97, 99);
            btnXoa.TabIndex = 3;
            btnXoa.Text = "Xóa";
            btnXoa.UseVisualStyleBackColor = false;
            btnXoa.Click += btnXoa_Click;
            // 
            // btnKQ
            // 
            btnKQ.BackColor = SystemColors.ButtonShadow;
            btnKQ.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnKQ.Location = new Point(46, 307);
            btnKQ.Name = "btnKQ";
            btnKQ.Size = new Size(172, 63);
            btnKQ.TabIndex = 4;
            btnKQ.Text = "Kết quả";
            btnKQ.UseVisualStyleBackColor = false;
            btnKQ.Click += btnKQ_Click;
            // 
            // txtKQ
            // 
            txtKQ.Font = new Font("Times New Roman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtKQ.Location = new Point(224, 324);
            txtKQ.Name = "txtKQ";
            txtKQ.Size = new Size(427, 30);
            txtKQ.TabIndex = 5;
            // 
            // Đổi_kiểu_chữ
            // 
            AutoScaleDimensions = new SizeF(8F, 17F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 382);
            Controls.Add(txtKQ);
            Controls.Add(btnKQ);
            Controls.Add(btnXoa);
            Controls.Add(groupBox1);
            Controls.Add(txtHoTen);
            Controls.Add(label1);
            Font = new Font("Microsoft Sans Serif", 8.25F);
            Name = "Đổi_kiểu_chữ";
            Text = "Đổi_kiểu_chữ";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtHoTen;
        private GroupBox groupBox1;
        private RadioButton rad2;
        private RadioButton rad1;
        private Button btnXoa;
        private Button btnKQ;
        private TextBox txtKQ;
    }
}